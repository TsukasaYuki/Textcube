<?php
/// Copyright (c) 2004-2018, Needlworks  / Tatter Network Foundation
/// All rights reserved. Licensed under the GPL.
/// See the GNU General Public License for more details. (/documents/LICENSE, /documents/COPYRIGHT)

/*
	id : d
	frame : f
	transition : t
	navigation : n 
	slideshowInterval : si
	page : p
	align : a
	image : i (*!)
*/

$images = explode('*!',$_GET['i']);
$imageStr = '';
define('ROOT', '../../..');
require ROOT . '/library/preprocessor.php';
foreach($images as $value) {
	$imageStr .= $value.'*!';
}
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css">
			/*<![CDATA[*/
				body
				{
					margin-left             : 0;
					margin-top              : 0;
					margin-right            : 0;
					margin-bottom           : 0;
					width                   : 100%;
					height                  : 100%;
				}
			/*]]>*/
		</style>
	</head>
	<body>

	</body>
</html>
