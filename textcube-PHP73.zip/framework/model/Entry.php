<?php
/// Copyright (c) 2004-2018, Needlworks  / Tatter Network Foundation
/// All rights reserved. Licensed under the GPL.
/// See the GNU General Public License for more details. (/documents/LICENSE, /documents/COPYRIGHT)

// TODO: 하나의 데이터베이스만 사용한다고 가정할 것인가(django style), 아니면 각 Model마다 서로 다른 DB 설정을 사용할 수 있게 할 것인가(cakephp style)?

class Entry extends Model {
}

?>
